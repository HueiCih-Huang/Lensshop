-- ============================================================
--  LensShop 資料庫結構
--  步驟：phpMyAdmin → 選 lensshop 資料庫 → 匯入此檔案
--  請先在 phpMyAdmin 建立名為 lensshop 的資料庫再匯入
-- ============================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- 1. 使用者表（含管理員）
CREATE TABLE IF NOT EXISTS users (
    user_id    INT           PRIMARY KEY AUTO_INCREMENT,
    username   VARCHAR(50)   NOT NULL UNIQUE,
    password   VARCHAR(255)  NOT NULL,
    email      VARCHAR(100)  NOT NULL UNIQUE,
    role       ENUM('user','admin') NOT NULL DEFAULT 'user',
    created_at DATETIME      DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. 商品分類表
CREATE TABLE IF NOT EXISTS categories (
    category_id   INT         PRIMARY KEY AUTO_INCREMENT,
    category_name VARCHAR(50) NOT NULL UNIQUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. 商品主表（一個品項 = 一款式，不含度數）
--    pack_size：幾片裝（日拋10、月拋1~2、年拋1）
CREATE TABLE IF NOT EXISTS products (
    product_id   INT           PRIMARY KEY AUTO_INCREMENT,
    product_name VARCHAR(100)  NOT NULL,
    brand        VARCHAR(50)   NOT NULL,
    color        VARCHAR(30),
    pack_size    INT           NOT NULL DEFAULT 1  COMMENT '幾片裝',
    price        DECIMAL(10,2) NOT NULL,
    description  TEXT,
    image_url    VARCHAR(255),
    category_id  INT,
    created_at   DATETIME      DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(category_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. 商品度數庫存表（每個度數各自管庫存）
--    degree = '平光' 表示無度數（彩色片常見）
CREATE TABLE IF NOT EXISTS product_degrees (
    degree_id  INT         PRIMARY KEY AUTO_INCREMENT,
    product_id INT         NOT NULL,
    degree     VARCHAR(20) NOT NULL  COMMENT '例：平光 / -1.00 / -2.50',
    stock      INT         NOT NULL DEFAULT 0,
    FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE CASCADE,
    UNIQUE KEY uq_product_degree (product_id, degree)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. 購物車主表（一人一車）
CREATE TABLE IF NOT EXISTS carts (
    cart_id    INT      PRIMARY KEY AUTO_INCREMENT,
    user_id    INT      NOT NULL UNIQUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. 購物車明細（記錄選擇的度數）
CREATE TABLE IF NOT EXISTS cart_items (
    cart_item_id INT PRIMARY KEY AUTO_INCREMENT,
    cart_id      INT NOT NULL,
    degree_id    INT NOT NULL,
    quantity     INT NOT NULL DEFAULT 1,
    FOREIGN KEY (cart_id)   REFERENCES carts(cart_id)          ON DELETE CASCADE,
    FOREIGN KEY (degree_id) REFERENCES product_degrees(degree_id),
    UNIQUE KEY uq_cart_degree (cart_id, degree_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7. 訂單主表
CREATE TABLE IF NOT EXISTS orders (
    order_id     INT           PRIMARY KEY AUTO_INCREMENT,
    user_id      INT           NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    order_status ENUM('pending','paid','shipped') NOT NULL DEFAULT 'pending',
    created_at   DATETIME      DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 8. 訂單明細（快照當時價格與度數文字）
CREATE TABLE IF NOT EXISTS order_items (
    order_item_id INT           PRIMARY KEY AUTO_INCREMENT,
    order_id      INT           NOT NULL,
    product_id    INT           NOT NULL,
    degree        VARCHAR(20)   NOT NULL  COMMENT '快照度數文字',
    quantity      INT           NOT NULL,
    price         DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id)   REFERENCES orders(order_id),
    FOREIGN KEY (product_id) REFERENCES products(product_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;
