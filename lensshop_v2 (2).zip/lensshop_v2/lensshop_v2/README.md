# LensShop 隱形眼鏡購物平台 v2

## 使用前必做：匯入資料庫

1. 開啟 XAMPP，啟動 MySQL
2. 瀏覽器開啟 http://localhost/phpmyadmin
3. 建立資料庫：名稱 `lensshop`，排序選 `utf8mb4_unicode_ci`
4. 選擇 lensshop 資料庫 → 上方點「匯入」
5. **依序**匯入 sql/ 資料夾中的兩個檔案：
   - 先匯入 `01_schema.sql`（建立資料表）
   - 再匯入 `02_seed_data.sql`（寫入初始資料）

## 啟動網站

```bash
pip install flask pymysql werkzeug
```

打開 app.py，修改密碼：
```python
'password': '你的XAMPP密碼',
```

```bash
python app.py
```

瀏覽器開啟 http://127.0.0.1:5000

## Demo 帳號

| 帳號   | 密碼       | 身份   |
|--------|-----------|--------|
| user1  | user1234  | 一般會員 |
| user2  | user1234  | 一般會員 |
| admin  | admin123  | 管理員   |

## 資料表結構（8張）

| 資料表           | 說明                         |
|-----------------|------------------------------|
| users           | 使用者（含管理員、新註冊用戶） |
| categories      | 商品分類                     |
| products        | 商品主表（含片裝數）           |
| product_degrees | 每個商品各度數的庫存           |
| carts           | 購物車主表                   |
| cart_items      | 購物車明細（含度數）           |
| orders          | 訂單主表                     |
| order_items     | 訂單明細（含度數快照）         |
