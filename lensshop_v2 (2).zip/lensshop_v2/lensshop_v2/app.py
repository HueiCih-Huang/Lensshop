from flask import Flask, render_template, request, redirect, url_for, session, flash
import pymysql
import pymysql.cursors
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps

app = Flask(__name__)
app.secret_key = 'lensshopp_secret_key_2024'

# ── 資料庫連線設定 ─────────────────────────────────────────────
# 請依照你的 XAMPP 環境修改 password
DB_CONFIG = {
    'host':        'localhost',
    'port':        3306,
    'user':        'root',
    'password':    '',        # ← 填入你的 XAMPP MySQL 密碼
    'database':    'lensshop',
    'charset':     'utf8mb4',
    'cursorclass': pymysql.cursors.DictCursor
}

def get_db():
    return pymysql.connect(**DB_CONFIG)

# ── 自動注入導覽列數量計數器 ───────────────────────────────────────
# ── 自動注入導覽列數量計數器 (修正資料表 JOIN 邏輯) ─────────────────────
@app.context_processor
def inject_nav_counts():
    """自動在所有範本中注入目前會員的購物車商品數與未處理訂單數"""
    cart_count = 0
    order_count = 0
    
    # 檢查是否有登入，且身分是一般會員 (admin 不需要顯示這些)
    if 'user_id' in session and session.get('role') == 'user':
        user_id = session['user_id']
        try:
            conn = get_db()
            c = conn.cursor()
            
            # 1. 透過 JOIN 結合 cart 與 cart_items，計算該會員購物車內的商品總數量
            c.execute("""
                SELECT SUM(ci.quantity) as total 
                FROM cart_items ci
                JOIN carts c ON ci.cart_id = c.cart_id
                WHERE c.user_id = %s
            """, (user_id,))
            res_cart = c.fetchone()
            if res_cart and res_cart['total']:
                cart_count = int(res_cart['total'])
                
            # 2. 計算 orders 表中，該會員「待付款(pending)」與「已付款(paid)」的訂單數量
            c.execute("""
                SELECT COUNT(*) as total 
                FROM orders 
                WHERE user_id = %s AND order_status IN ('pending', 'paid')
            """, (user_id,))
            res_order = c.fetchone()
            if res_order and res_order['total']:
                order_count = int(res_order['total'])
                
            c.close()
            conn.close()
        except Exception as e:
            # 防止資料庫查詢失敗導致整個網站掛掉，會在終端機印出錯誤
            print(f"導覽列計數器查詢出錯: {e}")
            
    return dict(cart_count=cart_count, order_count=order_count)

# ── Auth decorators ────────────────────────────────────────────
def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            flash('請先登入', 'warning')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session or session.get('role') != 'admin':
            flash('需要管理員權限', 'danger')
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated

# ── 首頁 ──────────────────────────────────────────────────────
@app.route('/')
def index():
    conn = get_db(); c = conn.cursor()
    category_id = request.args.get('cat', type=int)
    search      = request.args.get('q', '').strip()

    # 商品列表（含各商品總庫存）
    sql = """
        SELECT p.*, cat.category_name,
               COALESCE(SUM(pd.stock), 0) AS total_stock
        FROM products p
        LEFT JOIN categories cat      ON p.category_id = cat.category_id
        LEFT JOIN product_degrees pd  ON p.product_id  = pd.product_id
        WHERE 1=1
    """
    params = []
    if category_id:
        sql += " AND p.category_id=%s"; params.append(category_id)
    if search:
        sql += " AND (p.product_name LIKE %s OR p.brand LIKE %s OR p.color LIKE %s)"
        params += [f'%{search}%'] * 3
    sql += " GROUP BY p.product_id ORDER BY p.created_at DESC"
    c.execute(sql, params)
    products = c.fetchall()

    # 每個商品的度數清單（帶 degree_id、庫存）
    if products:
        pids = [p['product_id'] for p in products]
        fmt  = ','.join(['%s'] * len(pids))
        c.execute(
            f"SELECT * FROM product_degrees WHERE product_id IN ({fmt}) ORDER BY FIELD(degree,'平光'), degree",
            pids
        )
        deg_map = {}
        for row in c.fetchall():
            deg_map.setdefault(row['product_id'], []).append(row)
        for p in products:
            p['degree_list'] = deg_map.get(p['product_id'], [])
    else:
        for p in products:
            p['degree_list'] = []

    c.execute("SELECT * FROM categories ORDER BY category_id")
    categories = c.fetchall()

    cart_count = 0
    if 'user_id' in session:
        c.execute("SELECT cart_id FROM carts WHERE user_id=%s", (session['user_id'],))
        cart = c.fetchone()
        if cart:
            c.execute("SELECT COALESCE(SUM(quantity),0) AS t FROM cart_items WHERE cart_id=%s", (cart['cart_id'],))
            cart_count = c.fetchone()['t'] or 0

    c.close(); conn.close()
    return render_template('index.html', products=products, categories=categories,
                           selected_cat=category_id, search=search, cart_count=cart_count)

# ── 註冊 ──────────────────────────────────────────────────────
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username'].strip()
        password = request.form['password']
        email    = request.form['email'].strip()
        if not username or not password or not email:
            flash('所有欄位皆為必填', 'danger')
            return render_template('register.html')
        if len(password) < 6:
            flash('密碼至少需要 6 個字元', 'danger')
            return render_template('register.html')
        conn = get_db(); c = conn.cursor()
        try:
            c.execute(
                "INSERT INTO users(username, password, email) VALUES(%s,%s,%s)",
                (username, generate_password_hash(password), email)
            )
            conn.commit()
            flash('註冊成功，請登入！', 'success')
            return redirect(url_for('login'))
        except pymysql.err.IntegrityError:
            flash('帳號或 Email 已被使用', 'danger')
        finally:
            c.close(); conn.close()
    return render_template('register.html')

# ── 登入 / 登出 ────────────────────────────────────────────────
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username'].strip()
        password = request.form['password']
        conn = get_db(); c = conn.cursor()
        c.execute("SELECT * FROM users WHERE username=%s", (username,))
        user = c.fetchone(); c.close(); conn.close()
        if user and check_password_hash(user['password'], password):
            session['user_id']  = user['user_id']
            session['username'] = user['username']
            session['role']     = user['role']
            flash(f'歡迎回來，{user["username"]}！', 'success')
            return redirect(url_for('admin_products') if user['role'] == 'admin' else url_for('index'))
        flash('帳號或密碼錯誤', 'danger')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash('已登出', 'info')
    return redirect(url_for('index'))

# ── 購物車 ─────────────────────────────────────────────────────
def get_or_create_cart(c, conn, user_id):
    c.execute("SELECT cart_id FROM carts WHERE user_id=%s", (user_id,))
    row = c.fetchone()
    if not row:
        c.execute("INSERT INTO carts(user_id) VALUES(%s)", (user_id,))
        conn.commit()
        return c.lastrowid
    return row['cart_id']

@app.route('/cart/add', methods=['POST'])
@login_required
def add_to_cart():
    degree_id = request.form.get('degree_id', type=int)
    qty       = request.form.get('quantity',  type=int, default=1)
    if not degree_id:
        flash('請選擇度數', 'warning')
        return redirect(url_for('index'))

    conn = get_db(); c = conn.cursor()
    c.execute("""
        SELECT pd.*, p.product_name
        FROM product_degrees pd
        JOIN products p ON pd.product_id = p.product_id
        WHERE pd.degree_id = %s
    """, (degree_id,))
    deg = c.fetchone()
    if not deg:
        flash('度數不存在', 'danger'); c.close(); conn.close()
        return redirect(url_for('index'))

    cart_id = get_or_create_cart(c, conn, session['user_id'])
    c.execute("SELECT * FROM cart_items WHERE cart_id=%s AND degree_id=%s", (cart_id, degree_id))
    existing = c.fetchone()
    new_qty  = (existing['quantity'] if existing else 0) + qty

    if deg['stock'] < new_qty:
        flash(f'「{deg["product_name"]} {deg["degree"]}」庫存不足（剩 {deg["stock"]} 片）', 'warning')
        c.close(); conn.close()
        return redirect(url_for('index'))

    if existing:
        c.execute("UPDATE cart_items SET quantity=%s WHERE cart_item_id=%s",
                  (new_qty, existing['cart_item_id']))
    else:
        c.execute("INSERT INTO cart_items(cart_id, degree_id, quantity) VALUES(%s,%s,%s)",
                  (cart_id, degree_id, qty))

    conn.commit(); c.close(); conn.close()
    flash('已加入購物車！', 'success')
    return redirect(url_for('index'))

@app.route('/cart')
@login_required
def cart():
    conn = get_db(); c = conn.cursor()
    c.execute("SELECT cart_id FROM carts WHERE user_id=%s", (session['user_id'],))
    cart_row = c.fetchone(); items = []; total = 0
    if cart_row:
        c.execute("""
            SELECT ci.cart_item_id, ci.quantity,
                   pd.degree_id, pd.degree, pd.stock,
                   p.product_id, p.product_name, p.brand,
                   p.price, p.image_url, p.pack_size
            FROM cart_items ci
            JOIN product_degrees pd ON ci.degree_id  = pd.degree_id
            JOIN products p         ON pd.product_id = p.product_id
            WHERE ci.cart_id = %s
        """, (cart_row['cart_id'],))
        items = c.fetchall()
        total = sum(i['price'] * i['quantity'] for i in items)
    c.close(); conn.close()
    return render_template('cart.html', items=items, total=total)

@app.route('/cart/update/<int:cart_item_id>', methods=['POST'])
@login_required
def update_cart(cart_item_id):
    qty = request.form.get('quantity', type=int, default=1)
    conn = get_db(); c = conn.cursor()
    c.execute("""
        SELECT ci.*, pd.stock FROM cart_items ci
        JOIN product_degrees pd ON ci.degree_id  = pd.degree_id
        JOIN carts ct           ON ci.cart_id    = ct.cart_id
        WHERE ci.cart_item_id=%s AND ct.user_id=%s
    """, (cart_item_id, session['user_id']))
    item = c.fetchone()
    if item:
        if qty < 1:
            c.execute("DELETE FROM cart_items WHERE cart_item_id=%s", (cart_item_id,))
        elif qty > item['stock']:
            flash('超過庫存數量', 'warning')
        else:
            c.execute("UPDATE cart_items SET quantity=%s WHERE cart_item_id=%s", (qty, cart_item_id))
        conn.commit()
    c.close(); conn.close()
    return redirect(url_for('cart'))

@app.route('/cart/remove/<int:cart_item_id>', methods=['POST'])
@login_required
def remove_from_cart(cart_item_id):
    conn = get_db(); c = conn.cursor()
    c.execute("""
        DELETE ci FROM cart_items ci
        JOIN carts ct ON ci.cart_id = ct.cart_id
        WHERE ci.cart_item_id=%s AND ct.user_id=%s
    """, (cart_item_id, session['user_id']))
    conn.commit(); c.close(); conn.close()
    return redirect(url_for('cart'))

# ── 結帳 ───────────────────────────────────────────────────────
@app.route('/checkout', methods=['POST'])
@login_required
def checkout():
    conn = get_db(); c = conn.cursor()
    c.execute("SELECT cart_id FROM carts WHERE user_id=%s", (session['user_id'],))
    cart_row = c.fetchone()
    if not cart_row:
        flash('購物車是空的', 'warning'); c.close(); conn.close()
        return redirect(url_for('cart'))

    c.execute("""
        SELECT ci.quantity,
               pd.degree_id, pd.degree, pd.stock,
               p.product_id, p.product_name, p.price
        FROM cart_items ci
        JOIN product_degrees pd ON ci.degree_id  = pd.degree_id
        JOIN products p         ON pd.product_id = p.product_id
        WHERE ci.cart_id = %s
    """, (cart_row['cart_id'],))
    items = c.fetchall()

    if not items:
        flash('購物車是空的', 'warning'); c.close(); conn.close()
        return redirect(url_for('cart'))

    for item in items:
        if item['quantity'] > item['stock']:
            flash(f'「{item["product_name"]} {item["degree"]}」庫存不足', 'danger')
            c.close(); conn.close()
            return redirect(url_for('cart'))

    total = sum(i['price'] * i['quantity'] for i in items)
    c.execute("INSERT INTO orders(user_id, total_amount) VALUES(%s,%s)", (session['user_id'], total))
    order_id = c.lastrowid

    for item in items:
        c.execute("""
            INSERT INTO order_items(order_id, product_id, degree, quantity, price)
            VALUES(%s,%s,%s,%s,%s)
        """, (order_id, item['product_id'], item['degree'], item['quantity'], item['price']))
        c.execute("UPDATE product_degrees SET stock=stock-%s WHERE degree_id=%s",
                  (item['quantity'], item['degree_id']))

    c.execute("DELETE FROM cart_items WHERE cart_id=%s", (cart_row['cart_id'],))
    conn.commit(); c.close(); conn.close()
    flash(f'訂單 #{order_id} 已成立！', 'success')
    return redirect(url_for('orders'))

# ── 訂單 ───────────────────────────────────────────────────────
@app.route('/orders')
@login_required
def orders():
    conn = get_db(); c = conn.cursor()
    c.execute("SELECT * FROM orders WHERE user_id=%s ORDER BY created_at DESC", (session['user_id'],))
    order_list = c.fetchall()
    order_items = {}
    for o in order_list:
        c.execute("""
            SELECT oi.*, p.product_name, p.image_url, p.pack_size
            FROM order_items oi
            JOIN products p ON oi.product_id = p.product_id
            WHERE oi.order_id = %s
        """, (o['order_id'],))
        order_items[o['order_id']] = c.fetchall()
    c.close(); conn.close()
    return render_template('orders.html', orders=order_list, order_items=order_items)

@app.route('/orders/<int:order_id>/pay', methods=['POST'])
@login_required
def pay_order(order_id):
    conn = get_db(); c = conn.cursor()
    c.execute("""UPDATE orders SET order_status='paid'
                 WHERE order_id=%s AND user_id=%s AND order_status='pending'""",
              (order_id, session['user_id']))
    conn.commit(); c.close(); conn.close()
    flash('付款成功！', 'success')
    return redirect(url_for('orders'))

# ── 管理員：商品 ───────────────────────────────────────────────
@app.route('/admin/products')
@admin_required
def admin_products():
    conn = get_db(); c = conn.cursor()
    c.execute("""
        SELECT p.*, cat.category_name,
               COALESCE(SUM(pd.stock),0) AS total_stock
        FROM products p
        LEFT JOIN categories cat     ON p.category_id = cat.category_id
        LEFT JOIN product_degrees pd ON p.product_id  = pd.product_id
        GROUP BY p.product_id
        ORDER BY p.created_at DESC
    """)
    products = c.fetchall()
    deg_map = {}
    for p in products:
        c.execute("SELECT * FROM product_degrees WHERE product_id=%s ORDER BY FIELD(degree,'平光'), degree",
                  (p['product_id'],))
        deg_map[p['product_id']] = c.fetchall()
    c.execute("SELECT * FROM categories ORDER BY category_id")
    categories = c.fetchall()
    c.close(); conn.close()
    return render_template('admin_products.html', products=products,
                           deg_map=deg_map, categories=categories)

@app.route('/admin/products/add', methods=['POST'])
@admin_required
def admin_add_product():
    d = request.form; conn = get_db(); c = conn.cursor()
    c.execute("""
        INSERT INTO products(product_name,brand,color,pack_size,price,description,image_url,category_id)
        VALUES(%s,%s,%s,%s,%s,%s,%s,%s)
    """, (d['product_name'], d['brand'], d.get('color',''), int(d.get('pack_size',1)),
          float(d['price']), d.get('description',''), d.get('image_url',''),
          d.get('category_id') or None))
    conn.commit(); c.close(); conn.close()
    flash('商品已新增，請繼續新增度數', 'success')
    return redirect(url_for('admin_products'))

@app.route('/admin/products/edit/<int:product_id>', methods=['POST'])
@admin_required
def admin_edit_product(product_id):
    d = request.form; conn = get_db(); c = conn.cursor()
    c.execute("""
        UPDATE products SET product_name=%s,brand=%s,color=%s,pack_size=%s,
        price=%s,description=%s,image_url=%s,category_id=%s WHERE product_id=%s
    """, (d['product_name'], d['brand'], d.get('color',''), int(d.get('pack_size',1)),
          float(d['price']), d.get('description',''), d.get('image_url',''),
          d.get('category_id') or None, product_id))
    conn.commit(); c.close(); conn.close()
    flash('商品已更新', 'success')
    return redirect(url_for('admin_products'))

@app.route('/admin/products/delete/<int:product_id>', methods=['POST'])
@admin_required
def admin_delete_product(product_id):
    conn = get_db(); c = conn.cursor()
    c.execute("DELETE FROM products WHERE product_id=%s", (product_id,))
    conn.commit(); c.close(); conn.close()
    flash('商品已刪除', 'success')
    return redirect(url_for('admin_products'))

# ── 管理員：度數管理 ───────────────────────────────────────────
@app.route('/admin/products/<int:product_id>/degrees/add', methods=['POST'])
@admin_required
def admin_add_degree(product_id):
    degree = request.form['degree'].strip()
    stock  = int(request.form.get('stock', 0))
    conn = get_db(); c = conn.cursor()
    try:
        c.execute("INSERT INTO product_degrees(product_id,degree,stock) VALUES(%s,%s,%s)",
                  (product_id, degree, stock))
        conn.commit()
        flash(f'度數 {degree} 已新增', 'success')
    except pymysql.err.IntegrityError:
        flash(f'度數 {degree} 已存在', 'warning')
    finally:
        c.close(); conn.close()
    return redirect(url_for('admin_products'))

@app.route('/admin/degrees/edit/<int:degree_id>', methods=['POST'])
@admin_required
def admin_edit_degree(degree_id):
    stock = int(request.form.get('stock', 0))
    conn = get_db(); c = conn.cursor()
    c.execute("UPDATE product_degrees SET stock=%s WHERE degree_id=%s", (stock, degree_id))
    conn.commit(); c.close(); conn.close()
    flash('庫存已更新', 'success')
    return redirect(url_for('admin_products'))

@app.route('/admin/degrees/delete/<int:degree_id>', methods=['POST'])
@admin_required
def admin_delete_degree(degree_id):
    conn = get_db(); c = conn.cursor()
    c.execute("DELETE FROM product_degrees WHERE degree_id=%s", (degree_id,))
    conn.commit(); c.close(); conn.close()
    flash('度數已刪除', 'success')
    return redirect(url_for('admin_products'))

# ── 管理員：訂單 ───────────────────────────────────────────────
@app.route('/admin/orders')
@admin_required
def admin_orders():
    conn = get_db(); c = conn.cursor()
    c.execute("""
        SELECT o.*, u.username FROM orders o
        JOIN users u ON o.user_id = u.user_id
        ORDER BY o.created_at DESC
    """)
    order_list = c.fetchall()
    order_items = {}
    for o in order_list:
        c.execute("""
            SELECT oi.*, p.product_name FROM order_items oi
            JOIN products p ON oi.product_id = p.product_id
            WHERE oi.order_id = %s
        """, (o['order_id'],))
        order_items[o['order_id']] = c.fetchall()
    c.close(); conn.close()
    return render_template('admin_orders.html', orders=order_list, order_items=order_items)

@app.route('/admin/orders/<int:order_id>/status', methods=['POST'])
@admin_required
def admin_update_order_status(order_id):
    status = request.form['status']
    conn = get_db(); c = conn.cursor()
    c.execute("UPDATE orders SET order_status=%s WHERE order_id=%s", (status, order_id))
    conn.commit(); c.close(); conn.close()
    flash('訂單狀態已更新', 'success')
    return redirect(url_for('admin_orders'))

if __name__ == '__main__':
    app.run(debug=True, port=5000)
